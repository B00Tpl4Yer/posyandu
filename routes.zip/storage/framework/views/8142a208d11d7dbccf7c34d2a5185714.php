<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Kelola Pembelajaran Anak</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Kategori</th>
                <th>Judul</th>
                <th>Video</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($video->kategori); ?></td>
                <td><?php echo e($video->judul); ?></td>
                <td>
                    <iframe width="560" height="315" src="<?php echo e($video->url_video); ?>" frameborder="0" allowfullscreen></iframe>
                </td>
                <td><?php echo e($video->deskripsi); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.edit-pembelajaran-anak.form', $video->id)); ?>" class="btn btn-primary">Edit</a>
                    <form action="<?php echo e(route('admin.hapus-pembelajaran-anak', $video->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\database\laragon\www\project1\resources\views/admin/kelola-pembelajaran-anak.blade.php ENDPATH**/ ?>