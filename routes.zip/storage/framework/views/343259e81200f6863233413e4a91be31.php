
    <div class="container">
        <h1>Artikel Publik</h1>
        <hr>

        <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <?php if($artikel->foto): ?>
                    <img src="<?php echo e(asset('storage/' . $artikel->foto)); ?>" class="card-img-top" alt="Foto Artikel">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($artikel->judul); ?></h5>
                    <p class="card-text"><?php echo e($artikel->konten); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php /**PATH D:\database\laragon\www\project1\resources\views/artikel-publik.blade.php ENDPATH**/ ?>