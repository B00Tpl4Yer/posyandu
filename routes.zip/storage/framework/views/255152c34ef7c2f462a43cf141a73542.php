<?php
$user = Auth::user();
$coba = '';

if ($user && $user->hasRole('admin')) {
    $coba = 'layouts.admin';
} elseif ($user && $user->hasRole('pengguna terdaftar')) {
    $coba = 'layouts.app';
} else {
    $coba = 'layouts.public';
}
?>



<?php $__env->startSection('content'); ?>
    <div class="text-black dark:text-white mb-52 mt-8">
        <?php if(session('success')): ?>
<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
        <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container grid justify-items-center w-96">
            <?php if($artikel->foto): ?>
            <img src="<?php echo e(asset('artikel/' . $artikel->foto)); ?>" class="border rounded-lg w-full" alt="Foto Artikel">
            <?php endif; ?>
            <div class="mt-10">
                <h5 class="text-3xl text-center"><?php echo e($artikel->judul); ?></h5>
                <p class="text-lg text-center mb-4">Penulis:<?php echo e($artikel->penulis); ?></p>
                <div class="grid grid-cols-1 w-96">
                    <p class="text-sm w-full"><?php echo $artikel->konten; ?></p>
                    
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($coba, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\database\laragon\www\project1\resources\views/welcome.blade.php ENDPATH**/ ?>