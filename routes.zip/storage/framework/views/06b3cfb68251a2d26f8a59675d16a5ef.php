<?php
$user = Auth::user();
$incl = '';

if ($user && $user->hasRole('admin')) {
    $incl = 'layouts.admin';
} elseif ($user && $user->hasRole('pengguna terdaftar')) {
    $incl = 'layouts.app';
} else {
    $incl = 'layouts.public';
}
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="w-96">
        <h1 class="text-center text-3xl font-medium text-black dark:text-white mt-28 xl:mt-2">Selamat datang di posyandu</h1>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($incl, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\database\laragon\www\project1\resources\views/dashboard.blade.php ENDPATH**/ ?>