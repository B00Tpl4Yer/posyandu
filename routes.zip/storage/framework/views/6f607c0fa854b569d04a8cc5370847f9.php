<span class="self-center font-bold whitespace-nowrap text-gray-600 dark:text-white">
    <span class="text-xl sm:text-2xl xl:text-3xl  ">Posyandu </span>
</span>
<?php /**PATH D:\database\laragon\www\project1\resources\views/components/application-logo.blade.php ENDPATH**/ ?>