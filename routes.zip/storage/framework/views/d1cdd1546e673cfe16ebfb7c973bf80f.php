<?php
$user = Auth::user();
$clude = '';

if ($user && $user->hasRole('admin')) {
$clude = 'layouts.admin';
} elseif ($user && $user->hasRole('pengguna terdaftar')) {
$clude = 'layouts.app';
} else {
$clude = 'layouts.public';
}
?>


<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 justify-center mt-20 mb-56">
    <div class="text-center text-3xl font-semibold text-black dark:text-white mb-3">video Pembelajaran <br> untuk Balita</div>
    <div class="border rounded-lg w-96 border-gray-300 dark:border-white">
        <iframe src="https://www.youtube.com/embed/MlqCRowZsZ4?si=JJp1AUkclmp06tcJ" class="rounded-lg w-96 h-96" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($clude, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\database\laragon\www\project1\resources\views/batita.blade.php ENDPATH**/ ?>