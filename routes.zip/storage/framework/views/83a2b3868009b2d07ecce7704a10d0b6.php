 <!-- Pastikan layout Anda sudah ada -->

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Daftar Pengguna Terdaftar</h1>
    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Email</th>
                <!-- Tambahkan kolom lain sesuai kebutuhan -->
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $penggunaterdaftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($key + 1); ?></th>
                <td><?php echo e($pengguna->name); ?></td>
                <td><?php echo e($pengguna->email); ?></td>
                <!-- Tambahkan kolom lain sesuai kebutuhan -->
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\database\laragon\www\project1\resources\views/penggunaterdaftar/index.blade.php ENDPATH**/ ?>