<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Edit Pembelajaran Anak</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.update-pembelajaran-anak', ['id' => $video->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="kategori">Kategori:</label>
                <input type="text" name="kategori" class="form-control" required value="<?php echo e($video->kategori); ?>">
            </div>
            <div class="form-group">
                <label for="judul">Judul:</label>
                <input type="text" name="judul" class="form-control" required value="<?php echo e($video->judul); ?>">
            </div>
            <div class="form-group">
                <label for="url_video">URL Video:</label>
                <input type="url" name="url_video" class="form-control" required value="<?php echo e($video->url_video); ?>">
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi:</label>
                <textarea name="deskripsi" class="form-control" rows="3" required><?php echo e($video->deskripsi); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\database\laragon\www\project1\resources\views/admin/edit-pembelajaran-anak.blade.php ENDPATH**/ ?>